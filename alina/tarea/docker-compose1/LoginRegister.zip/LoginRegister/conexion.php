<?php 

$servername="localhost";
$username="root";
$password=""; //si se esta en clase cambiar el password a ($password="AlumnoIFP";)
$database="users1"; //se le tiene que llamar a la base de datos users1

$conn = mysqli_connect($servername,$username,$password,$database);

if(!$conn){
    die("Conexión fallida");
}

?>